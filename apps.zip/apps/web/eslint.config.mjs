// @ts-check
import baseConfig from '../../eslint.config.mjs';

/**
 * Web-specific ESLint config. Inherits the root rules. Next.js's
 * `eslint-config-next` is still legacy "extends" format and not yet a clean
 * flat-config consumer — adding it can come later when their flat-config path
 * stabilizes. Until then, root rules cover the meaningful ground.
 */
export default [
  ...baseConfig,
  {
    files: ['src/**/*.{ts,tsx}'],
    rules: {
      // React-specific eased rules can land here per-app as needed.
    },
  },
];
