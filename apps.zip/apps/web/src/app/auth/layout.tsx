import Link from 'next/link';

/**
 * Minimal centered layout for `/auth/*`. No AppShell — keeps these pages
 * focused on the single primary action.
 */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b">
        <div className="container flex h-14 items-center">
          <Link href="/" className="text-sm font-semibold tracking-tight">
            Auction
          </Link>
        </div>
      </header>
      <main className="flex flex-1 items-center justify-center px-4 py-10 sm:py-16">
        <div className="w-full max-w-md">{children}</div>
      </main>
    </div>
  );
}
