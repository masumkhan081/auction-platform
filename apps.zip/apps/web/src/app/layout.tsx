import type { Metadata } from 'next';
import { Providers } from '@/components/providers/providers';
import { getServerSession } from '@/lib/auth/session.server';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'Auction', template: '%s · Auction' },
  description: 'Real-time auction platform.',
  icons: { icon: '/favicon.ico' },
};

export const viewport = {
  themeColor: '#0f172a',
  width: 'device-width',
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const initialSession = await getServerSession();
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-dvh font-sans">
        <Providers initialSession={initialSession}>{children}</Providers>
      </body>
    </html>
  );
}
